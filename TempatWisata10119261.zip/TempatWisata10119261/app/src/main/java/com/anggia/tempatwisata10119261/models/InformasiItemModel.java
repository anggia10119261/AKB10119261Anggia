package com.anggia.tempatwisata10119261.models;
/*
    nim                 : 10119261
    nama                : Anggia Regina Wulandari
    kelas               : IF-7
*/
public class InformasiItemModel {
    public String title, desc;

    public InformasiItemModel(String title, String desc) {
        this.title = title;
        this.desc = desc;
    }
}
